"use client"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/supabase"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Search, Edit, Trash2, BarChart3, Users, FileText, ArrowUpDown } from "lucide-react"
import { useRouter } from "next/navigation"

interface Lead {
  id: string
  first_name: string
  last_name: string
  email: string
  phone: string
  status: string
  lead_source: string
  priority: string
  estimated_value: number
  created_at: string
  assigned_user?: {
    id: string
    full_name: string
  }
}

interface User {
  id: string
  full_name: string
  roles: { name: string }
  lead_count: number
  qualified_leads: number
  total_value: number
}

export default function OverviewPage() {
  const { userProfile } = useAuth()
  const router = useRouter()
  const [allLeads, setAllLeads] = useState<Lead[]>([])
  const [allUsers, setAllUsers] = useState<User[]>([])
  const [filteredLeads, setFilteredLeads] = useState<Lead[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [userFilter, setUserFilter] = useState("all")
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null)
  const [editingLead, setEditingLead] = useState<any>(null)
  const [showEditDialog, setShowEditDialog] = useState(false)
  const [showReassignDialog, setShowReassignDialog] = useState(false)
  const [reassignToUser, setReassignToUser] = useState("")

  useEffect(() => {
    if (userProfile?.roles?.name !== "admin") {
      router.push("/dashboard")
      return
    }
    fetchAllData()
  }, [userProfile, router])

  useEffect(() => {
    applyFilters()
  }, [allLeads, searchTerm, statusFilter, userFilter])

  const fetchAllData = async () => {
    try {
      // Fetch all leads
      const { data: leadsData, error: leadsError } = await supabase
        .from("leads")
        .select("*")
        .order("created_at", { ascending: false })

      if (leadsError) throw leadsError

      // Fetch all lead assignments
      const { data: assignmentsData, error: assignmentsError } = await supabase
        .from("lead_assignments")
        .select("lead_id, user_id")

      if (assignmentsError) throw assignmentsError

      // Fetch all users
      const { data: usersData, error: usersError } = await supabase
        .from("user_profiles")
        .select(`
          *,
          roles!user_profiles_role_id_fkey (
            name
          )
        `)
        .order("full_name", { ascending: true })

      if (usersError) throw usersError

      // Create lookup maps
      const userMap = new Map()
      usersData?.forEach((user) => {
        userMap.set(user.id, user)
      })

      const assignmentMap = new Map()
      assignmentsData?.forEach((assignment) => {
        assignmentMap.set(assignment.lead_id, assignment.user_id)
      })

      // Combine leads with their assigned users
      const leadsWithAssignments =
        leadsData?.map((lead) => {
          const assignedUserId = assignmentMap.get(lead.id)
          const assignedUser = assignedUserId ? userMap.get(assignedUserId) : null

          return {
            ...lead,
            assigned_user: assignedUser
              ? {
                  id: assignedUser.id,
                  full_name: assignedUser.full_name,
                }
              : null,
          }
        }) || []

      // Calculate user stats
      const usersWithStats =
        usersData?.map((user) => {
          const userLeads = leadsWithAssignments.filter((lead) => lead.assigned_user?.id === user.id)
          const qualifiedLeads = userLeads.filter(
            (lead) => lead.status === "qualified" || lead.status === "proposal" || lead.status === "closed",
          )
          const totalValue = userLeads.reduce((sum, lead) => sum + (lead.estimated_value || 0), 0)

          return {
            ...user,
            lead_count: userLeads.length,
            qualified_leads: qualifiedLeads.length,
            total_value: totalValue,
          }
        }) || []

      setAllLeads(leadsWithAssignments)
      setAllUsers(usersWithStats)
    } catch (error) {
      console.error("Error fetching data:", error)
    } finally {
      setLoading(false)
    }
  }

  const applyFilters = () => {
    let filtered = [...allLeads]

    // Apply search
    if (searchTerm) {
      const term = searchTerm.toLowerCase()
      filtered = filtered.filter(
        (lead) =>
          lead.first_name.toLowerCase().includes(term) ||
          lead.last_name.toLowerCase().includes(term) ||
          lead.email?.toLowerCase().includes(term) ||
          lead.phone?.toLowerCase().includes(term),
      )
    }

    // Apply status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter((lead) => lead.status === statusFilter)
    }

    // Apply user filter
    if (userFilter !== "all") {
      if (userFilter === "unassigned") {
        filtered = filtered.filter((lead) => !lead.assigned_user)
      } else {
        filtered = filtered.filter((lead) => lead.assigned_user?.id === userFilter)
      }
    }

    setFilteredLeads(filtered)
  }

  const updateLead = async () => {
    if (!editingLead) return

    try {
      const { error } = await supabase
        .from("leads")
        .update({
          first_name: editingLead.first_name,
          last_name: editingLead.last_name,
          email: editingLead.email,
          phone: editingLead.phone,
          status: editingLead.status,
          priority: editingLead.priority,
          estimated_value: editingLead.estimated_value,
          lead_source: editingLead.lead_source,
          updated_at: new Date().toISOString(),
        })
        .eq("id", editingLead.id)

      if (error) throw error

      setShowEditDialog(false)
      setEditingLead(null)
      fetchAllData()
    } catch (error) {
      console.error("Error updating lead:", error)
    }
  }

  const reassignLead = async () => {
    if (!selectedLead || !reassignToUser) return

    try {
      // Remove existing assignment
      await supabase.from("lead_assignments").delete().eq("lead_id", selectedLead.id)

      // Add new assignment
      const { error } = await supabase.from("lead_assignments").insert({
        lead_id: selectedLead.id,
        user_id: reassignToUser,
      })

      if (error) throw error

      // Add activity
      await supabase.from("activities").insert({
        lead_id: selectedLead.id,
        user_id: reassignToUser,
        activity_type: "reassignment",
        description: "Lead reassigned by admin",
      })

      setShowReassignDialog(false)
      setSelectedLead(null)
      setReassignToUser("")
      fetchAllData()
    } catch (error) {
      console.error("Error reassigning lead:", error)
    }
  }

  const deleteLead = async (leadId: string) => {
    if (!confirm("Are you sure you want to delete this lead? This action cannot be undone.")) return

    try {
      const { error } = await supabase.from("leads").delete().eq("id", leadId)

      if (error) throw error

      fetchAllData()
    } catch (error) {
      console.error("Error deleting lead:", error)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "new":
        return "bg-blue-100 text-blue-800"
      case "contacted":
        return "bg-yellow-100 text-yellow-800"
      case "qualified":
        return "bg-green-100 text-green-800"
      case "proposal":
        return "bg-purple-100 text-purple-800"
      case "closed":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(value)
  }

  if (loading) {
    return <div className="text-center py-8">Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Admin Overview</h1>
        <div className="text-sm text-muted-foreground">
          Total: {allLeads.length} leads | {allUsers.filter((u) => u.roles.name === "sales_rep").length} sales reps
        </div>
      </div>

      <Tabs defaultValue="leads" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="leads">
            <FileText className="w-4 h-4 mr-2" />
            All Leads
          </TabsTrigger>
          <TabsTrigger value="users">
            <Users className="w-4 h-4 mr-2" />
            Team Performance
          </TabsTrigger>
          <TabsTrigger value="analytics">
            <BarChart3 className="w-4 h-4 mr-2" />
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="leads" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>All Leads Management</CardTitle>
              <CardDescription>View, edit, and manage all leads across your organization</CardDescription>
              <div className="flex flex-col sm:flex-row gap-2 mt-4">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search leads..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="new">New</SelectItem>
                    <SelectItem value="contacted">Contacted</SelectItem>
                    <SelectItem value="qualified">Qualified</SelectItem>
                    <SelectItem value="proposal">Proposal</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={userFilter} onValueChange={setUserFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by user" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Users</SelectItem>
                    <SelectItem value="unassigned">Unassigned</SelectItem>
                    {allUsers
                      .filter((user) => user.roles.name === "sales_rep")
                      .map((user) => (
                        <SelectItem key={user.id} value={user.id}>
                          {user.full_name}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Contact</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Source</TableHead>
                      <TableHead>Value</TableHead>
                      <TableHead>Assigned To</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredLeads.map((lead) => (
                      <TableRow key={lead.id}>
                        <TableCell className="font-medium">
                          {lead.first_name} {lead.last_name}
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">
                            <div>{lead.email}</div>
                            <div className="text-muted-foreground">{lead.phone}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(lead.status)}>{lead.status}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{lead.lead_source}</Badge>
                        </TableCell>
                        <TableCell>{formatCurrency(lead.estimated_value || 0)}</TableCell>
                        <TableCell>
                          {lead.assigned_user ? (
                            <span className="text-sm">{lead.assigned_user.full_name}</span>
                          ) : (
                            <span className="text-sm text-muted-foreground">Unassigned</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setEditingLead(lead)
                                setShowEditDialog(true)
                              }}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedLead(lead)
                                setShowReassignDialog(true)
                              }}
                            >
                              <ArrowUpDown className="w-4 h-4" />
                            </Button>
                            <Button variant="outline" size="sm" onClick={() => deleteLead(lead.id)}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users">
          <Card>
            <CardHeader>
              <CardTitle>Team Performance</CardTitle>
              <CardDescription>Overview of your sales team performance and lead distribution</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Sales Rep</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Total Leads</TableHead>
                    <TableHead>Qualified</TableHead>
                    <TableHead>Conversion Rate</TableHead>
                    <TableHead>Potential Value</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {allUsers.map((user) => {
                    const conversionRate =
                      user.lead_count > 0 ? Math.round((user.qualified_leads / user.lead_count) * 100) : 0

                    return (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.full_name}</TableCell>
                        <TableCell>
                          <Badge variant={user.roles.name === "admin" ? "default" : "secondary"}>
                            {user.roles.name}
                          </Badge>
                        </TableCell>
                        <TableCell>{user.lead_count}</TableCell>
                        <TableCell>{user.qualified_leads}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="w-full bg-gray-200 rounded-full h-2.5 max-w-[100px]">
                              <div
                                className="bg-green-600 h-2.5 rounded-full"
                                style={{ width: `${conversionRate}%` }}
                              />
                            </div>
                            <span>{conversionRate}%</span>
                          </div>
                        </TableCell>
                        <TableCell>{formatCurrency(user.total_value)}</TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Lead Distribution</CardTitle>
                <CardDescription>How leads are distributed across your team</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {allUsers
                    .filter((user) => user.roles.name === "sales_rep")
                    .map((user) => {
                      const percentage = allLeads.length > 0 ? Math.round((user.lead_count / allLeads.length) * 100) : 0

                      return (
                        <div key={user.id} className="space-y-2">
                          <div className="flex justify-between">
                            <span>{user.full_name}</span>
                            <span>
                              {user.lead_count} leads ({percentage}%)
                            </span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2.5">
                            <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${percentage}%` }} />
                          </div>
                        </div>
                      )
                    })}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Overall Statistics</CardTitle>
                <CardDescription>Key metrics for your organization</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Total Leads</span>
                    <span className="font-medium">{allLeads.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Unassigned Leads</span>
                    <span className="font-medium">{allLeads.filter((lead) => !lead.assigned_user).length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Qualified Leads</span>
                    <span className="font-medium">{allLeads.filter((lead) => lead.status === "qualified").length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Potential Value</span>
                    <span className="font-medium text-green-600">
                      {formatCurrency(allLeads.reduce((sum, lead) => sum + (lead.estimated_value || 0), 0))}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Average Deal Size</span>
                    <span className="font-medium">
                      {formatCurrency(
                        allLeads.reduce((sum, lead) => sum + (lead.estimated_value || 0), 0) / (allLeads.length || 1),
                      )}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Edit Lead Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Lead</DialogTitle>
            <DialogDescription>Update lead information</DialogDescription>
          </DialogHeader>
          {editingLead && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit_first_name">First Name</Label>
                  <Input
                    id="edit_first_name"
                    value={editingLead.first_name}
                    onChange={(e) => setEditingLead({ ...editingLead, first_name: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="edit_last_name">Last Name</Label>
                  <Input
                    id="edit_last_name"
                    value={editingLead.last_name}
                    onChange={(e) => setEditingLead({ ...editingLead, last_name: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="edit_email">Email</Label>
                <Input
                  id="edit_email"
                  value={editingLead.email}
                  onChange={(e) => setEditingLead({ ...editingLead, email: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="edit_phone">Phone</Label>
                <Input
                  id="edit_phone"
                  value={editingLead.phone}
                  onChange={(e) => setEditingLead({ ...editingLead, phone: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit_status">Status</Label>
                  <Select
                    value={editingLead.status}
                    onValueChange={(value) => setEditingLead({ ...editingLead, status: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new">New</SelectItem>
                      <SelectItem value="contacted">Contacted</SelectItem>
                      <SelectItem value="qualified">Qualified</SelectItem>
                      <SelectItem value="proposal">Proposal</SelectItem>
                      <SelectItem value="closed">Closed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="edit_priority">Priority</Label>
                  <Select
                    value={editingLead.priority}
                    onValueChange={(value) => setEditingLead({ ...editingLead, priority: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label htmlFor="edit_value">Estimated Value ($)</Label>
                <Input
                  id="edit_value"
                  type="number"
                  value={editingLead.estimated_value}
                  onChange={(e) =>
                    setEditingLead({ ...editingLead, estimated_value: Number.parseFloat(e.target.value) || 0 })
                  }
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowEditDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={updateLead}>Update Lead</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Reassign Lead Dialog */}
      <Dialog open={showReassignDialog} onOpenChange={setShowReassignDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reassign Lead</DialogTitle>
            <DialogDescription>
              {selectedLead && `Reassign ${selectedLead.first_name} ${selectedLead.last_name} to a different sales rep`}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="reassign_user">Assign to</Label>
              <Select value={reassignToUser} onValueChange={setReassignToUser}>
                <SelectTrigger>
                  <SelectValue placeholder="Select sales rep" />
                </SelectTrigger>
                <SelectContent>
                  {allUsers
                    .filter((user) => user.roles.name === "sales_rep")
                    .map((user) => (
                      <SelectItem key={user.id} value={user.id}>
                        {user.full_name} ({user.lead_count} leads)
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowReassignDialog(false)}>
                Cancel
              </Button>
              <Button onClick={reassignLead} disabled={!reassignToUser}>
                Reassign Lead
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
