"use client"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/supabase"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Phone, Mail, MapPin, Plus, Calendar, Search, Clock } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"

interface Lead {
  id: string
  first_name: string
  last_name: string
  email: string
  phone: string
  address: string
  city: string
  state: string
  zip: string
  status: string
  notes: string
  created_at: string
  lead_source: string
  priority: string
  estimated_value: number
  next_follow_up: string | null
  last_contacted: string | null
}

interface LeadStats {
  total: number
  new: number
  contacted: number
  qualified: number
  proposal: number
  closed: number
}

export default function DashboardPage() {
  const { user } = useAuth()
  const [leads, setLeads] = useState<Lead[]>([])
  const [filteredLeads, setFilteredLeads] = useState<Lead[]>([])
  const [stats, setStats] = useState<LeadStats>({
    total: 0,
    new: 0,
    contacted: 0,
    qualified: 0,
    proposal: 0,
    closed: 0,
  })
  const [loading, setLoading] = useState(true)
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null)
  const [activityNote, setActivityNote] = useState("")
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [priorityFilter, setPriorityFilter] = useState("all")
  const [upcomingAppointments, setUpcomingAppointments] = useState<any[]>([])

  useEffect(() => {
    if (user) {
      fetchLeads()
      fetchAppointments()
    }
  }, [user])

  useEffect(() => {
    if (leads.length > 0) {
      applyFilters()
    }
  }, [leads, searchTerm, statusFilter, priorityFilter])

  const fetchLeads = async () => {
    try {
      const { data, error } = await supabase
        .from("leads")
        .select(`
          *,
          lead_assignments!inner (
            user_id
          )
        `)
        .eq("lead_assignments.user_id", user?.id)
        .order("created_at", { ascending: false })

      if (error) throw error

      const leadsData = data || []
      setLeads(leadsData)

      // Calculate stats
      const newStats = {
        total: leadsData.length,
        new: leadsData.filter((lead) => lead.status === "new").length,
        contacted: leadsData.filter((lead) => lead.status === "contacted").length,
        qualified: leadsData.filter((lead) => lead.status === "qualified").length,
        proposal: leadsData.filter((lead) => lead.status === "proposal").length,
        closed: leadsData.filter((lead) => lead.status === "closed").length,
      }
      setStats(newStats)
    } catch (error) {
      console.error("Error fetching leads:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchAppointments = async () => {
    try {
      const { data, error } = await supabase
        .from("appointments")
        .select(`
          *,
          leads (
            first_name,
            last_name
          )
        `)
        .eq("user_id", user?.id)
        .gte("scheduled_at", new Date().toISOString())
        .order("scheduled_at", { ascending: true })
        .limit(5)

      if (error) throw error
      setUpcomingAppointments(data || [])
    } catch (error) {
      console.error("Error fetching appointments:", error)
    }
  }

  const applyFilters = () => {
    let filtered = [...leads]

    // Apply search
    if (searchTerm) {
      const term = searchTerm.toLowerCase()
      filtered = filtered.filter(
        (lead) =>
          lead.first_name.toLowerCase().includes(term) ||
          lead.last_name.toLowerCase().includes(term) ||
          lead.email?.toLowerCase().includes(term) ||
          lead.phone?.toLowerCase().includes(term) ||
          lead.city?.toLowerCase().includes(term),
      )
    }

    // Apply status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter((lead) => lead.status === statusFilter)
    }

    // Apply priority filter
    if (priorityFilter !== "all") {
      filtered = filtered.filter((lead) => lead.priority === priorityFilter)
    }

    setFilteredLeads(filtered)
  }

  const updateLeadStatus = async (leadId: string, status: string) => {
    try {
      const { error } = await supabase
        .from("leads")
        .update({ status, updated_at: new Date().toISOString() })
        .eq("id", leadId)

      if (error) throw error

      // Add activity
      await supabase.from("activities").insert({
        lead_id: leadId,
        user_id: user?.id,
        activity_type: "status_change",
        description: `Status changed to ${status}`,
      })

      fetchLeads()
    } catch (error) {
      console.error("Error updating lead status:", error)
    }
  }

  const updateLeadPriority = async (leadId: string, priority: string) => {
    try {
      const { error } = await supabase
        .from("leads")
        .update({ priority, updated_at: new Date().toISOString() })
        .eq("id", leadId)

      if (error) throw error

      fetchLeads()
    } catch (error) {
      console.error("Error updating lead priority:", error)
    }
  }

  const addActivity = async () => {
    if (!selectedLead || !activityNote.trim()) return

    try {
      const { error } = await supabase.from("activities").insert({
        lead_id: selectedLead.id,
        user_id: user?.id,
        activity_type: "note",
        description: activityNote,
      })

      if (error) throw error

      setActivityNote("")
      setSelectedLead(null)
      fetchLeads()
    } catch (error) {
      console.error("Error adding activity:", error)
    }
  }

  const scheduleAppointment = async (leadId: string, title: string, description: string, scheduledAt: string) => {
    try {
      const { error } = await supabase.from("appointments").insert({
        lead_id: leadId,
        user_id: user?.id,
        title,
        description,
        scheduled_at: scheduledAt,
      })

      if (error) throw error

      // Add activity
      await supabase.from("activities").insert({
        lead_id: leadId,
        user_id: user?.id,
        activity_type: "appointment",
        description: `Appointment scheduled: ${title}`,
      })

      fetchAppointments()
    } catch (error) {
      console.error("Error scheduling appointment:", error)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "new":
        return "bg-blue-100 text-blue-800"
      case "contacted":
        return "bg-yellow-100 text-yellow-800"
      case "qualified":
        return "bg-green-100 text-green-800"
      case "proposal":
        return "bg-purple-100 text-purple-800"
      case "closed":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-orange-100 text-orange-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(value)
  }

  if (loading) {
    return <div className="text-center py-8">Loading your leads...</div>
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Leads</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">New</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.new}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Contacted</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{stats.contacted}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Qualified</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.qualified}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Proposals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{stats.proposal}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>My Leads</CardTitle>
              <CardDescription>Manage your assigned leads</CardDescription>
              <div className="flex flex-col sm:flex-row gap-2 mt-2">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search leads..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="new">New</SelectItem>
                    <SelectItem value="contacted">Contacted</SelectItem>
                    <SelectItem value="qualified">Qualified</SelectItem>
                    <SelectItem value="proposal">Proposal</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Priorities</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {filteredLeads.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  {leads.length === 0 ? "No leads assigned yet." : "No leads match your filters."}
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredLeads.map((lead) => (
                    <Card key={lead.id} className="overflow-hidden">
                      <div className="flex flex-col md:flex-row">
                        <div className="flex-1 p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-semibold text-lg">
                                {lead.first_name} {lead.last_name}
                              </h3>
                              <div className="flex flex-wrap gap-2 mt-1">
                                <Badge className={getStatusColor(lead.status)}>{lead.status}</Badge>
                                <Badge className={getPriorityColor(lead.priority)}>{lead.priority}</Badge>
                                <Badge variant="outline">{lead.lead_source}</Badge>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="font-medium text-green-600">
                                {formatCurrency(lead.estimated_value || 0)}
                              </div>
                              <div className="text-xs text-muted-foreground">Estimated Value</div>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-3 text-sm">
                            {lead.email && (
                              <div className="flex items-center text-muted-foreground">
                                <Mail className="w-4 h-4 mr-2" />
                                <a href={`mailto:${lead.email}`} className="hover:text-primary">
                                  {lead.email}
                                </a>
                              </div>
                            )}
                            {lead.phone && (
                              <div className="flex items-center text-muted-foreground">
                                <Phone className="w-4 h-4 mr-2" />
                                <a href={`tel:${lead.phone}`} className="hover:text-primary">
                                  {lead.phone}
                                </a>
                              </div>
                            )}
                            {lead.city && (
                              <div className="flex items-center text-muted-foreground">
                                <MapPin className="w-4 h-4 mr-2" />
                                <span>
                                  {lead.city}, {lead.state} {lead.zip}
                                </span>
                              </div>
                            )}
                            {lead.next_follow_up && (
                              <div className="flex items-center text-muted-foreground">
                                <Clock className="w-4 h-4 mr-2" />
                                <span>Follow up: {new Date(lead.next_follow_up).toLocaleDateString()}</span>
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="bg-muted/20 p-4 flex flex-row md:flex-col justify-between gap-2">
                          <Select
                            defaultValue={lead.status}
                            onValueChange={(value) => updateLeadStatus(lead.id, value)}
                          >
                            <SelectTrigger className="w-full">
                              <SelectValue placeholder="Status" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="new">New</SelectItem>
                              <SelectItem value="contacted">Contacted</SelectItem>
                              <SelectItem value="qualified">Qualified</SelectItem>
                              <SelectItem value="proposal">Proposal</SelectItem>
                              <SelectItem value="closed">Closed</SelectItem>
                            </SelectContent>
                          </Select>

                          <Select
                            defaultValue={lead.priority}
                            onValueChange={(value) => updateLeadPriority(lead.id, value)}
                          >
                            <SelectTrigger className="w-full">
                              <SelectValue placeholder="Priority" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="high">High</SelectItem>
                              <SelectItem value="medium">Medium</SelectItem>
                              <SelectItem value="low">Low</SelectItem>
                            </SelectContent>
                          </Select>

                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                variant="outline"
                                size="sm"
                                className="w-full"
                                onClick={() => setSelectedLead(lead)}
                              >
                                <Plus className="w-4 h-4 mr-2" />
                                Add Note
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Add Note</DialogTitle>
                                <DialogDescription>
                                  Add a note for {lead.first_name} {lead.last_name}
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <Textarea
                                  placeholder="Enter your note..."
                                  value={activityNote}
                                  onChange={(e) => setActivityNote(e.target.value)}
                                />
                                <div className="flex justify-end space-x-2">
                                  <Button variant="outline" onClick={() => setSelectedLead(null)}>
                                    Cancel
                                  </Button>
                                  <Button onClick={addActivity}>Add Note</Button>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>

                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm" className="w-full">
                                <Calendar className="w-4 h-4 mr-2" />
                                Schedule
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Schedule Appointment</DialogTitle>
                                <DialogDescription>
                                  Schedule an appointment with {lead.first_name} {lead.last_name}
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div>
                                  <label className="block text-sm font-medium mb-1">Title</label>
                                  <Input placeholder="Appointment title" id="title" />
                                </div>
                                <div>
                                  <label className="block text-sm font-medium mb-1">Date & Time</label>
                                  <Input type="datetime-local" id="scheduled_at" />
                                </div>
                                <div>
                                  <label className="block text-sm font-medium mb-1">Notes</label>
                                  <Textarea placeholder="Appointment details..." id="description" />
                                </div>
                                <div className="flex justify-end space-x-2">
                                  <Button variant="outline">Cancel</Button>
                                  <Button
                                    onClick={() => {
                                      const title = (document.getElementById("title") as HTMLInputElement).value
                                      const scheduledAt = (document.getElementById("scheduled_at") as HTMLInputElement)
                                        .value
                                      const description = (
                                        document.getElementById("description") as HTMLTextAreaElement
                                      ).value
                                      scheduleAppointment(lead.id, title, description, scheduledAt)
                                    }}
                                  >
                                    Schedule
                                  </Button>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div>
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Upcoming Appointments</CardTitle>
              <CardDescription>Your scheduled appointments</CardDescription>
            </CardHeader>
            <CardContent>
              {upcomingAppointments.length === 0 ? (
                <div className="text-center py-4 text-muted-foreground">No upcoming appointments</div>
              ) : (
                <div className="space-y-4">
                  {upcomingAppointments.map((appointment) => (
                    <div key={appointment.id} className="border rounded-lg p-3">
                      <div className="font-medium">{appointment.title}</div>
                      <div className="text-sm text-muted-foreground">
                        {appointment.leads?.first_name} {appointment.leads?.last_name}
                      </div>
                      <div className="flex items-center mt-2 text-sm">
                        <Calendar className="w-4 h-4 mr-2 text-muted-foreground" />
                        <span>
                          {new Date(appointment.scheduled_at).toLocaleDateString()} at{" "}
                          {new Date(appointment.scheduled_at).toLocaleTimeString([], {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quick Stats</CardTitle>
              <CardDescription>Your performance this month</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="text-sm text-muted-foreground">Conversion Rate</div>
                  <div className="font-medium">
                    {stats.total > 0 ? Math.round((stats.qualified / stats.total) * 100) : 0}%
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <div className="text-sm text-muted-foreground">Avg. Deal Size</div>
                  <div className="font-medium">
                    {formatCurrency(
                      leads.reduce((sum, lead) => sum + (lead.estimated_value || 0), 0) / (leads.length || 1),
                    )}
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <div className="text-sm text-muted-foreground">Potential Revenue</div>
                  <div className="font-medium text-green-600">
                    {formatCurrency(leads.reduce((sum, lead) => sum + (lead.estimated_value || 0), 0))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
