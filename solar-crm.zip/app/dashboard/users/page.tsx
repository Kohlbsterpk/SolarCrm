"use client"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/supabase"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { UserPlus } from "lucide-react"
import { useRouter } from "next/navigation"

interface User {
  id: string
  full_name: string
  email: string
  role_id: number
  roles: { name: string }
  created_at: string
}

export default function UsersPage() {
  const { userProfile } = useAuth()
  const router = useRouter()
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [showAddUser, setShowAddUser] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [filteredUsers, setFilteredUsers] = useState<User[]>([])
  const [newUser, setNewUser] = useState({
    email: "",
    password: "",
    full_name: "",
    role_id: 2,
  })
  const [userStats, setUserStats] = useState<any[]>([])

  useEffect(() => {
    if (userProfile?.roles?.name !== "admin") {
      router.push("/dashboard")
      return
    }
    fetchUsers()
  }, [userProfile, router])

  useEffect(() => {
    if (users.length > 0) {
      applyFilters()
    }
  }, [users, searchTerm])

  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase
        .from("user_profiles")
        .select(`
          *,
          roles!user_profiles_role_id_fkey (
            name
          )
        `)
        .order("created_at", { ascending: false })

      if (error) throw error
      
      // Get user stats
      const userIds = data?.map(user => user.id) || []
      if (userIds.length > 0) {
        await fetchUserStats(userIds, data || [])
      }
      
      setUsers(data || [])
      setFilteredUsers(data || [])
    } catch (error) {
      console.error("Error fetching users:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchUserStats = async (userIds: string[], userData: User[]) => {
    try {
      // Get lead assignments for each user
      const { data: assignmentsData, error: assignmentsError } = await supabase
        .from("lead_assignments")
        .select(`
          user_id,
          lead_id,
          leads (
            status,
            estimated_value
          )
        `)
        .in("user_id", userIds)

      if (assignmentsError) throw assignmentsError

      // Calculate stats for each user
      const stats = userData.map(user => {
        const userAssignments = assignmentsData?.filter(a => a.user_id === user.id) || []
        const totalLeads = userAssignments.length
        const qualifiedLeads = userAssignments.filter(a => 
          a.leads?.status === "qualified" || 
          a.leads?.status === "proposal" || 
          a.leads?.status === "closed"
        ).length
        const potentialValue = userAssignments.reduce((sum, a) => sum + (a.leads?.estimated_value || 0), 0)
        
        return {
          userId: user.id,
          totalLeads,
          qualifiedLeads,
          conversionRate: totalLeads > 0 ? Math.round((qualifiedLeads / totalLeads) * 100) : 0,
          potentialValue
        }
      })
      
      setUserStats(stats)
    } catch (error) {
      console.error("Error fetching user stats:", error)
    }
  }

  const applyFilters = () => {
    if (!searchTerm) {
      setFilteredUsers(users)
      return
    }
    
    const term = searchTerm.toLowerCase()
    const filtered = users.filter(user => 
      user.full_name.toLowerCase().includes(term) || 
      user.email?.toLowerCase().includes(term) ||
      user.roles?.name.toLowerCase().includes(term)
    )
    
    setFilteredUsers(filtered)
  }

  const addUser = async () => {
    try {
      // Create auth user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: newUser.email,
        password: newUser.password,
        options: {
          data: {
            full_name: newUser.full_name
          }
        }
      })

      if (authError) throw authError

      // The trigger will automatically create the user profile
      // But we can update it with the role
      if (authData.user) {
        const { error: profileError } = await supabase
          .from("user_profiles")
          .update({
            role_id: newUser.role_id,
          })
          .eq("id", authData.user.id)

        if (profileError) throw profileError
      }

      setNewUser({
        email: "",
        password: "",
        full_name: "",
        role_id: 2,
      })
      setShowAddUser(false)
      fetchUsers()
    } catch (error) {
      console.error("Error adding user:", error)
    }
  }

  const getUserStats = (userId: string) => {
    return userStats.find(stat => stat.userId === userId) || {
      totalLeads: 0,
      qualifiedLeads: 0,
      conversionRate: 0,
      potentialValue: 0
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(value)
  }

  if (loading) {
    return <div className="text-center py-8">Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-2xl font-bold text-gray-900">User Management</h1>
        <Dialog open={showAddUser} onOpenChange={setShowAddUser}>
          <DialogTrigger asChild>
            <Button>
              <UserPlus className="w-4 h-4 mr-2" />
              Add User
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New User</DialogTitle>
              <DialogDescription>Create a new user account for your team.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="full_name">Full Name</Label>
                <Input
                  id="full_name"
                  value={newUser.full_name}
                  onChange={(e) => setNewUser({ ...newUser, full_name: e.target.value })}
                />
              </div>
              <div>
                \
