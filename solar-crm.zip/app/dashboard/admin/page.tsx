"use client"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/supabase"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Search, Download, Upload, BarChart3, FileText, Tag } from "lucide-react"
import { useRouter } from "next/navigation"

interface Lead {
  id: string
  first_name: string
  last_name: string
  email: string
  phone: string
  status: string
  created_at: string
  lead_source: string
  priority: string
  estimated_value: number
  assigned_user?: {
    id: string
    full_name: string
  }
}

interface User {
  id: string
  full_name: string
  email: string
}

interface LeadSource {
  id: number
  name: string
  color: string
}

export default function AdminPage() {
  const { userProfile } = useAuth()
  const router = useRouter()
  const [leads, setLeads] = useState<Lead[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [leadSources, setLeadSources] = useState<LeadSource[]>([])
  const [loading, setLoading] = useState(true)
  const [showAddLead, setShowAddLead] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [sourceFilter, setSourceFilter] = useState("all")
  const [filteredLeads, setFilteredLeads] = useState<Lead[]>([])
  const [newLead, setNewLead] = useState({
    first_name: "",
    last_name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    zip: "",
    lead_source: "Website",
    priority: "medium",
    estimated_value: 0,
  })
  const [newLeadSource, setNewLeadSource] = useState({
    name: "",
    color: "#3B82F6",
  })
  const [showAddLeadSource, setShowAddLeadSource] = useState(false)

  useEffect(() => {
    if (userProfile?.roles?.name !== "admin") {
      router.push("/dashboard")
      return
    }
    fetchData()
  }, [userProfile, router])

  useEffect(() => {
    if (leads.length > 0) {
      applyFilters()
    }
  }, [leads, searchTerm, statusFilter, sourceFilter])

  const fetchData = async () => {
    try {
      // Fetch all leads first
      const { data: leadsData, error: leadsError } = await supabase
        .from("leads")
        .select("*")
        .order("created_at", { ascending: false })

      if (leadsError) throw leadsError

      // Fetch all lead assignments
      const { data: assignmentsData, error: assignmentsError } = await supabase
        .from("lead_assignments")
        .select("lead_id, user_id")

      if (assignmentsError) throw assignmentsError

      // Fetch all user profiles
      const { data: usersData, error: usersError } = await supabase
        .from("user_profiles")
        .select(`
          id,
          full_name,
          created_at,
          roles!user_profiles_role_id_fkey (
            name
          )
        `)
        .eq("role_id", 2) // Sales reps only

      if (usersError) throw usersError

      // Fetch lead sources
      const { data: sourcesData, error: sourcesError } = await supabase
        .from("lead_sources")
        .select("*")
        .order("name", { ascending: true })

      if (sourcesError) throw sourcesError

      // Create a map of user profiles for quick lookup
      const userMap = new Map()
      usersData?.forEach((user) => {
        userMap.set(user.id, user)
      })

      // Create a map of assignments for quick lookup
      const assignmentMap = new Map()
      assignmentsData?.forEach((assignment) => {
        assignmentMap.set(assignment.lead_id, assignment.user_id)
      })

      // Combine leads with their assigned users
      const leadsWithAssignments =
        leadsData?.map((lead) => {
          const assignedUserId = assignmentMap.get(lead.id)
          const assignedUser = assignedUserId ? userMap.get(assignedUserId) : null

          return {
            ...lead,
            assigned_user: assignedUser
              ? {
                  id: assignedUser.id,
                  full_name: assignedUser.full_name,
                }
              : null,
          }
        }) || []

      // Transform users data
      const transformedUsers =
        usersData?.map((user) => ({
          id: user.id,
          full_name: user.full_name,
          email: user.id, // We'll need to get email from auth.users separately if needed
        })) || []

      setLeads(leadsWithAssignments)
      setUsers(transformedUsers)
      setLeadSources(sourcesData || [])
      setFilteredLeads(leadsWithAssignments)
    } catch (error) {
      console.error("Error fetching data:", error)
    } finally {
      setLoading(false)
    }
  }

  const applyFilters = () => {
    let filtered = [...leads]

    // Apply search
    if (searchTerm) {
      const term = searchTerm.toLowerCase()
      filtered = filtered.filter(
        (lead) =>
          lead.first_name.toLowerCase().includes(term) ||
          lead.last_name.toLowerCase().includes(term) ||
          lead.email?.toLowerCase().includes(term) ||
          lead.phone?.toLowerCase().includes(term),
      )
    }

    // Apply status filter
    if (statusFilter !== "all") {
      filtered = filtered.filter((lead) => lead.status === statusFilter)
    }

    // Apply source filter
    if (sourceFilter !== "all") {
      filtered = filtered.filter((lead) => lead.lead_source === sourceFilter)
    }

    setFilteredLeads(filtered)
  }

  const addLead = async () => {
    try {
      const { data, error } = await supabase.from("leads").insert([newLead]).select().single()

      if (error) throw error

      setNewLead({
        first_name: "",
        last_name: "",
        email: "",
        phone: "",
        address: "",
        city: "",
        state: "",
        zip: "",
        lead_source: "Website",
        priority: "medium",
        estimated_value: 0,
      })
      setShowAddLead(false)
      fetchData()
    } catch (error) {
      console.error("Error adding lead:", error)
    }
  }

  const addLeadSource = async () => {
    try {
      const { error } = await supabase.from("lead_sources").insert([newLeadSource])

      if (error) throw error

      setNewLeadSource({
        name: "",
        color: "#3B82F6",
      })
      setShowAddLeadSource(false)
      fetchData()
    } catch (error) {
      console.error("Error adding lead source:", error)
    }
  }

  const assignLead = async (leadId: string, userId: string) => {
    try {
      // First, remove any existing assignment for this lead
      await supabase.from("lead_assignments").delete().eq("lead_id", leadId)

      // Then add the new assignment
      const { error } = await supabase.from("lead_assignments").insert({
        lead_id: leadId,
        user_id: userId,
      })

      if (error) throw error
      fetchData()
    } catch (error) {
      console.error("Error assigning lead:", error)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "new":
        return "bg-blue-100 text-blue-800"
      case "contacted":
        return "bg-yellow-100 text-yellow-800"
      case "qualified":
        return "bg-green-100 text-green-800"
      case "proposal":
        return "bg-purple-100 text-purple-800"
      case "closed":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(value)
  }

  if (loading) {
    return <div className="text-center py-8">Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
        <div className="flex flex-wrap gap-2">
          <Dialog open={showAddLead} onOpenChange={setShowAddLead}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Add Lead
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Add New Lead</DialogTitle>
                <DialogDescription>Enter the lead information below.</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="first_name">First Name</Label>
                    <Input
                      id="first_name"
                      value={newLead.first_name}
                      onChange={(e) => setNewLead({ ...newLead, first_name: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="last_name">Last Name</Label>
                    <Input
                      id="last_name"
                      value={newLead.last_name}
                      onChange={(e) => setNewLead({ ...newLead, last_name: e.target.value })}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={newLead.email}
                    onChange={(e) => setNewLead({ ...newLead, email: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    value={newLead.phone}
                    onChange={(e) => setNewLead({ ...newLead, phone: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="address">Address</Label>
                  <Input
                    id="address"
                    value={newLead.address}
                    onChange={(e) => setNewLead({ ...newLead, address: e.target.value })}
                  />
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <Label htmlFor="city">City</Label>
                    <Input
                      id="city"
                      value={newLead.city}
                      onChange={(e) => setNewLead({ ...newLead, city: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="state">State</Label>
                    <Input
                      id="state"
                      value={newLead.state}
                      onChange={(e) => setNewLead({ ...newLead, state: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="zip">ZIP</Label>
                    <Input
                      id="zip"
                      value={newLead.zip}
                      onChange={(e) => setNewLead({ ...newLead, zip: e.target.value })}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="lead_source">Lead Source</Label>
                    <Select
                      value={newLead.lead_source}
                      onValueChange={(value) => setNewLead({ ...newLead, lead_source: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select source" />
                      </SelectTrigger>
                      <SelectContent>
                        {leadSources.map((source) => (
                          <SelectItem key={source.id} value={source.name}>
                            {source.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="priority">Priority</Label>
                    <Select
                      value={newLead.priority}
                      onValueChange={(value) => setNewLead({ ...newLead, priority: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select priority" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="low">Low</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="estimated_value">Estimated Value ($)</Label>
                  <Input
                    id="estimated_value"
                    type="number"
                    value={newLead.estimated_value.toString()}
                    onChange={(e) =>
                      setNewLead({ ...newLead, estimated_value: Number.parseFloat(e.target.value) || 0 })
                    }
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setShowAddLead(false)}>
                    Cancel
                  </Button>
                  <Button onClick={addLead}>Add Lead</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={showAddLeadSource} onOpenChange={setShowAddLeadSource}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                Add Source
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Lead Source</DialogTitle>
                <DialogDescription>Create a new lead source category</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="source_name">Source Name</Label>
                  <Input
                    id="source_name"
                    value={newLeadSource.name}
                    onChange={(e) => setNewLeadSource({ ...newLeadSource, name: e.target.value })}
                    placeholder="e.g., Trade Show, Partner"
                  />
                </div>
                <div>
                  <Label htmlFor="source_color">Color</Label>
                  <div className="flex gap-2">
                    <Input
                      id="source_color"
                      type="color"
                      value={newLeadSource.color}
                      onChange={(e) => setNewLeadSource({ ...newLeadSource, color: e.target.value })}
                      className="w-16 h-10 p-1"
                    />
                    <Input
                      value={newLeadSource.color}
                      onChange={(e) => setNewLeadSource({ ...newLeadSource, color: e.target.value })}
                      className="flex-1"
                    />
                  </div>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setShowAddLeadSource(false)}>
                    Cancel
                  </Button>
                  <Button onClick={addLeadSource}>Add Source</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Button variant="outline">
            <Upload className="w-4 h-4 mr-2" />
            Import
          </Button>

          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Leads</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{leads.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Unassigned</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-600">
              {leads.filter((lead) => !lead.assigned_user).length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Qualified</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {leads.filter((lead) => lead.status === "qualified").length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Potential Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {formatCurrency(leads.reduce((sum, lead) => sum + (lead.estimated_value || 0), 0))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="leads">
        <TabsList className="grid w-full grid-cols-3 mb-4">
          <TabsTrigger value="leads">
            <FileText className="w-4 h-4 mr-2" />
            Leads
          </TabsTrigger>
          <TabsTrigger value="sources">
            <Tag className="w-4 h-4 mr-2" />
            Lead Sources
          </TabsTrigger>
          <TabsTrigger value="analytics">
            <BarChart3 className="w-4 h-4 mr-2" />
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="leads" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>All Leads</CardTitle>
              <CardDescription>Manage and assign leads to your sales team</CardDescription>
              <div className="flex flex-col sm:flex-row gap-2 mt-2">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search leads..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="new">New</SelectItem>
                    <SelectItem value="contacted">Contacted</SelectItem>
                    <SelectItem value="qualified">Qualified</SelectItem>
                    <SelectItem value="proposal">Proposal</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={sourceFilter} onValueChange={setSourceFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by source" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Sources</SelectItem>
                    {leadSources.map((source) => (
                      <SelectItem key={source.id} value={source.name}>
                        {source.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead>Value</TableHead>
                    <TableHead>Assigned To</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLeads.map((lead) => (
                    <TableRow key={lead.id}>
                      <TableCell className="font-medium">
                        {lead.first_name} {lead.last_name}
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div>{lead.email}</div>
                          <div className="text-gray-500">{lead.phone}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(lead.status)}>{lead.status}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{lead.lead_source}</Badge>
                      </TableCell>
                      <TableCell>{formatCurrency(lead.estimated_value || 0)}</TableCell>
                      <TableCell>
                        {lead.assigned_user ? (
                          <span className="text-sm">{lead.assigned_user.full_name}</span>
                        ) : (
                          <span className="text-sm text-gray-500">Unassigned</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {!lead.assigned_user && (
                          <Select onValueChange={(userId) => assignLead(lead.id, userId)}>
                            <SelectTrigger className="w-32">
                              <SelectValue placeholder="Assign" />
                            </SelectTrigger>
                            <SelectContent>
                              {users.map((user) => (
                                <SelectItem key={user.id} value={user.id}>
                                  {user.full_name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sources">
          <Card>
            <CardHeader>
              <CardTitle>Lead Sources</CardTitle>
              <CardDescription>Manage your lead source categories</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Source Name</TableHead>
                    <TableHead>Color</TableHead>
                    <TableHead>Lead Count</TableHead>
                    <TableHead>Conversion Rate</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {leadSources.map((source) => {
                    const sourceLeads = leads.filter((lead) => lead.lead_source === source.name)
                    const qualifiedLeads = sourceLeads.filter(
                      (lead) => lead.status === "qualified" || lead.status === "proposal" || lead.status === "closed",
                    )
                    const conversionRate =
                      sourceLeads.length > 0 ? Math.round((qualifiedLeads.length / sourceLeads.length) * 100) : 0

                    return (
                      <TableRow key={source.id}>
                        <TableCell className="font-medium">{source.name}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="w-4 h-4 rounded-full" style={{ backgroundColor: source.color }} />
                            <span>{source.color}</span>
                          </div>
                        </TableCell>
                        <TableCell>{sourceLeads.length}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="w-full bg-gray-200 rounded-full h-2.5">
                              <div
                                className="bg-green-600 h-2.5 rounded-full"
                                style={{ width: `${conversionRate}%` }}
                              />
                            </div>
                            <span>{conversionRate}%</span>
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle>Sales Analytics</CardTitle>
              <CardDescription>Performance metrics and insights</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                <div>
                  <h3 className="text-lg font-medium mb-4">Lead Status Distribution</h3>
                  <div className="h-64 flex items-end gap-4">
                    {["new", "contacted", "qualified", "proposal", "closed"].map((status) => {
                      const count = leads.filter((lead) => lead.status === status).length
                      const percentage = leads.length > 0 ? Math.round((count / leads.length) * 100) : 0
                      const maxHeight = 200
                      const height = leads.length > 0 ? Math.max(40, (count / leads.length) * maxHeight) : 40

                      return (
                        <div key={status} className="flex flex-col items-center flex-1">
                          <div
                            className={`w-full rounded-t-md ${getStatusColor(status)}`}
                            style={{ height: `${height}px` }}
                          />
                          <div className="mt-2 text-center">
                            <div className="font-medium capitalize">{status}</div>
                            <div className="text-sm text-muted-foreground">
                              {count} ({percentage}%)
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-medium mb-4">Lead Source Distribution</h3>
                    <div className="space-y-4">
                      {leadSources.map((source) => {
                        const count = leads.filter((lead) => lead.lead_source === source.name).length
                        const percentage = leads.length > 0 ? Math.round((count / leads.length) * 100) : 0

                        return (
                          <div key={source.id} className="space-y-2">
                            <div className="flex justify-between">
                              <span>{source.name}</span>
                              <span>
                                {count} leads ({percentage}%)
                              </span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2.5">
                              <div
                                className="h-2.5 rounded-full"
                                style={{
                                  width: `${percentage}%`,
                                  backgroundColor: source.color,
                                }}
                              />
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-4">Sales Rep Performance</h3>
                    <div className="space-y-4">
                      {users.map((user) => {
                        const userLeads = leads.filter((lead) => lead.assigned_user?.id === user.id)
                        const qualifiedLeads = userLeads.filter(
                          (lead) =>
                            lead.status === "qualified" || lead.status === "proposal" || lead.status === "closed",
                        )
                        const conversionRate =
                          userLeads.length > 0 ? Math.round((qualifiedLeads.length / userLeads.length) * 100) : 0

                        return (
                          <div key={user.id} className="space-y-2">
                            <div className="flex justify-between">
                              <span>{user.full_name}</span>
                              <span>
                                {userLeads.length} leads ({conversionRate}% qualified)
                              </span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2.5">
                              <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${conversionRate}%` }} />
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
