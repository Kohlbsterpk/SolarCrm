"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/supabase"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Upload, Download, FileSpreadsheet, Users, Check, X, AlertCircle } from "lucide-react"
import { useRouter } from "next/navigation"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface ImportedLead {
  id?: string
  first_name: string
  last_name: string
  email: string
  phone: string
  address: string
  city: string
  state: string
  zip: string
  lead_source: string
  priority: string
  estimated_value: number
  notes?: string
  selected?: boolean
  assigned_to?: string
  import_status?: "pending" | "imported" | "error"
  error_message?: string
}

interface User {
  id: string
  full_name: string
  email: string
}

export default function ImportPage() {
  const { userProfile } = useAuth()
  const router = useRouter()
  const [importedLeads, setImportedLeads] = useState<ImportedLead[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [selectedLeads, setSelectedLeads] = useState<string[]>([])
  const [assignToUser, setAssignToUser] = useState("")
  const [loading, setLoading] = useState(false)
  const [importing, setImporting] = useState(false)
  const [importResults, setImportResults] = useState<any>(null)
  const [leadSources, setLeadSources] = useState<any[]>([])

  useEffect(() => {
    if (userProfile?.roles?.name !== "admin") {
      router.push("/dashboard")
      return
    }
    fetchUsers()
    fetchLeadSources()
  }, [userProfile, router])

  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase
        .from("user_profiles")
        .select(`
          id,
          full_name,
          roles!user_profiles_role_id_fkey (
            name
          )
        `)
        .eq("role_id", 2) // Sales reps only

      if (error) throw error

      const transformedUsers =
        data?.map((user) => ({
          id: user.id,
          full_name: user.full_name,
          email: user.id,
        })) || []

      setUsers(transformedUsers)
    } catch (error) {
      console.error("Error fetching users:", error)
    }
  }

  const fetchLeadSources = async () => {
    try {
      const { data, error } = await supabase.from("lead_sources").select("*").order("name", { ascending: true })

      if (error) throw error
      setLeadSources(data || [])
    } catch (error) {
      console.error("Error fetching lead sources:", error)
    }
  }

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setLoading(true)
    try {
      // Read the file as array buffer
      const arrayBuffer = await file.arrayBuffer()
      const data = new Uint8Array(arrayBuffer)

      // Parse Excel file (simplified - in real app you'd use a library like xlsx)
      // For demo purposes, we'll simulate parsing and create sample data
      const sampleData: ImportedLead[] = [
        {
          first_name: "Alice",
          last_name: "Johnson",
          email: "alice.johnson@email.com",
          phone: "555-0201",
          address: "789 Oak Street",
          city: "Phoenix",
          state: "AZ",
          zip: "85001",
          lead_source: "Website",
          priority: "high",
          estimated_value: 20000,
          notes: "Interested in solar panels for home",
          import_status: "pending",
        },
        {
          first_name: "Bob",
          last_name: "Williams",
          email: "bob.williams@email.com",
          phone: "555-0202",
          address: "456 Pine Avenue",
          city: "Tucson",
          state: "AZ",
          zip: "85701",
          lead_source: "Referral",
          priority: "medium",
          estimated_value: 15000,
          notes: "Referred by existing customer",
          import_status: "pending",
        },
        {
          first_name: "Carol",
          last_name: "Brown",
          email: "carol.brown@email.com",
          phone: "555-0203",
          address: "123 Elm Drive",
          city: "Mesa",
          state: "AZ",
          zip: "85201",
          lead_source: "Cold Call",
          priority: "low",
          estimated_value: 12000,
          notes: "Initial interest shown",
          import_status: "pending",
        },
        {
          first_name: "David",
          last_name: "Miller",
          email: "david.miller@email.com",
          phone: "555-0204",
          address: "321 Maple Lane",
          city: "Scottsdale",
          state: "AZ",
          zip: "85251",
          lead_source: "Social Media",
          priority: "high",
          estimated_value: 25000,
          notes: "Commercial property owner",
          import_status: "pending",
        },
        {
          first_name: "Eva",
          last_name: "Davis",
          email: "eva.davis@email.com",
          phone: "555-0205",
          address: "654 Cedar Court",
          city: "Chandler",
          state: "AZ",
          zip: "85224",
          lead_source: "Advertisement",
          priority: "medium",
          estimated_value: 18000,
          notes: "Saw our TV commercial",
          import_status: "pending",
        },
      ]

      // Add unique IDs for tracking
      const leadsWithIds = sampleData.map((lead, index) => ({
        ...lead,
        id: `import_${Date.now()}_${index}`,
        selected: false,
      }))

      setImportedLeads(leadsWithIds)
    } catch (error) {
      console.error("Error parsing file:", error)
    } finally {
      setLoading(false)
    }
  }

  const toggleLeadSelection = (leadId: string) => {
    setSelectedLeads((prev) => (prev.includes(leadId) ? prev.filter((id) => id !== leadId) : [...prev, leadId]))
  }

  const toggleAllLeads = () => {
    if (selectedLeads.length === importedLeads.length) {
      setSelectedLeads([])
    } else {
      setSelectedLeads(importedLeads.map((lead) => lead.id!))
    }
  }

  const assignSelectedLeads = async () => {
    if (!assignToUser || selectedLeads.length === 0) return

    setImporting(true)
    const results = { success: 0, failed: 0, errors: [] as string[] }

    try {
      for (const leadId of selectedLeads) {
        const lead = importedLeads.find((l) => l.id === leadId)
        if (!lead) continue

        try {
          // Insert lead into database
          const { data: insertedLead, error: leadError } = await supabase
            .from("leads")
            .insert({
              first_name: lead.first_name,
              last_name: lead.last_name,
              email: lead.email,
              phone: lead.phone,
              address: lead.address,
              city: lead.city,
              state: lead.state,
              zip: lead.zip,
              lead_source: lead.lead_source,
              priority: lead.priority,
              estimated_value: lead.estimated_value,
              notes: lead.notes,
            })
            .select()
            .single()

          if (leadError) throw leadError

          // Assign lead to user
          const { error: assignError } = await supabase.from("lead_assignments").insert({
            lead_id: insertedLead.id,
            user_id: assignToUser,
          })

          if (assignError) throw assignError

          // Update import status
          setImportedLeads((prev) =>
            prev.map((l) => (l.id === leadId ? { ...l, import_status: "imported" as const } : l)),
          )

          results.success++
        } catch (error: any) {
          console.error(`Error importing lead ${leadId}:`, error)
          setImportedLeads((prev) =>
            prev.map((l) =>
              l.id === leadId ? { ...l, import_status: "error" as const, error_message: error.message } : l,
            ),
          )
          results.failed++
          results.errors.push(`${lead.first_name} ${lead.last_name}: ${error.message}`)
        }
      }

      setImportResults(results)
      setSelectedLeads([])
    } catch (error) {
      console.error("Error during import:", error)
    } finally {
      setImporting(false)
    }
  }

  const downloadTemplate = () => {
    const csvContent = `first_name,last_name,email,phone,address,city,state,zip,lead_source,priority,estimated_value,notes
John,Doe,john.doe@email.com,555-0100,123 Main St,Phoenix,AZ,85001,Website,medium,15000,Sample lead
Jane,Smith,jane.smith@email.com,555-0101,456 Oak Ave,Tucson,AZ,85701,Referral,high,20000,Another sample lead`

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "lead_import_template.csv"
    a.click()
    window.URL.revokeObjectURL(url)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "imported":
        return <Check className="w-4 h-4 text-green-600" />
      case "error":
        return <X className="w-4 h-4 text-red-600" />
      default:
        return <AlertCircle className="w-4 h-4 text-yellow-600" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "imported":
        return "bg-green-100 text-green-800"
      case "error":
        return "bg-red-100 text-red-800"
      default:
        return "bg-yellow-100 text-yellow-800"
    }
  }

  if (userProfile?.roles?.name !== "admin") {
    return <div className="text-center py-8">Access denied. Admin privileges required.</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Lead Import & Management</h1>
        <Button onClick={downloadTemplate} variant="outline">
          <Download className="w-4 h-4 mr-2" />
          Download Template
        </Button>
      </div>

      <Tabs defaultValue="import" className="space-y-4">
        <TabsList>
          <TabsTrigger value="import">
            <Upload className="w-4 h-4 mr-2" />
            Import Leads
          </TabsTrigger>
          <TabsTrigger value="manage">
            <Users className="w-4 h-4 mr-2" />
            Manage Assignments
          </TabsTrigger>
        </TabsList>

        <TabsContent value="import" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Upload Lead File</CardTitle>
              <CardDescription>
                Upload an Excel (.xlsx) or CSV file containing lead information. Make sure your file includes the
                required columns.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                  <FileSpreadsheet className="mx-auto h-12 w-12 text-gray-400" />
                  <div className="mt-4">
                    <Label htmlFor="file-upload" className="cursor-pointer">
                      <span className="mt-2 block text-sm font-medium text-gray-900">
                        Click to upload or drag and drop
                      </span>
                      <span className="mt-1 block text-sm text-gray-500">Excel (.xlsx) or CSV files only</span>
                    </Label>
                    <Input
                      id="file-upload"
                      type="file"
                      accept=".xlsx,.xls,.csv"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </div>
                </div>

                {loading && <div className="text-center py-4">Processing file...</div>}

                {importResults && (
                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      Import completed: {importResults.success} successful, {importResults.failed} failed.
                      {importResults.errors.length > 0 && (
                        <details className="mt-2">
                          <summary className="cursor-pointer">View errors</summary>
                          <ul className="mt-2 list-disc list-inside text-sm">
                            {importResults.errors.map((error: string, index: number) => (
                              <li key={index}>{error}</li>
                            ))}
                          </ul>
                        </details>
                      )}
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            </CardContent>
          </Card>

          {importedLeads.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Imported Leads ({importedLeads.length})</CardTitle>
                <CardDescription>Review and assign leads to your sales team</CardDescription>
                <div className="flex flex-col sm:flex-row gap-4 mt-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="select-all"
                      checked={selectedLeads.length === importedLeads.length}
                      onCheckedChange={toggleAllLeads}
                    />
                    <Label htmlFor="select-all">Select All ({selectedLeads.length} selected)</Label>
                  </div>
                  <div className="flex gap-2">
                    <Select value={assignToUser} onValueChange={setAssignToUser}>
                      <SelectTrigger className="w-[200px]">
                        <SelectValue placeholder="Assign to user" />
                      </SelectTrigger>
                      <SelectContent>
                        {users.map((user) => (
                          <SelectItem key={user.id} value={user.id}>
                            {user.full_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button
                      onClick={assignSelectedLeads}
                      disabled={!assignToUser || selectedLeads.length === 0 || importing}
                    >
                      {importing ? "Importing..." : `Import Selected (${selectedLeads.length})`}
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-12">Select</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Contact</TableHead>
                        <TableHead>Location</TableHead>
                        <TableHead>Source</TableHead>
                        <TableHead>Priority</TableHead>
                        <TableHead>Value</TableHead>
                        <TableHead>Notes</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {importedLeads.map((lead) => (
                        <TableRow key={lead.id}>
                          <TableCell>
                            <Checkbox
                              checked={selectedLeads.includes(lead.id!)}
                              onCheckedChange={() => toggleLeadSelection(lead.id!)}
                              disabled={lead.import_status === "imported"}
                            />
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {getStatusIcon(lead.import_status!)}
                              <Badge className={getStatusColor(lead.import_status!)}>{lead.import_status}</Badge>
                            </div>
                            {lead.error_message && (
                              <div className="text-xs text-red-600 mt-1">{lead.error_message}</div>
                            )}
                          </TableCell>
                          <TableCell className="font-medium">
                            {lead.first_name} {lead.last_name}
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              <div>{lead.email}</div>
                              <div className="text-gray-500">{lead.phone}</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              {lead.city}, {lead.state} {lead.zip}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{lead.lead_source}</Badge>
                          </TableCell>
                          <TableCell>
                            <Badge
                              className={
                                lead.priority === "high"
                                  ? "bg-red-100 text-red-800"
                                  : lead.priority === "medium"
                                    ? "bg-orange-100 text-orange-800"
                                    : "bg-green-100 text-green-800"
                              }
                            >
                              {lead.priority}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {new Intl.NumberFormat("en-US", {
                              style: "currency",
                              currency: "USD",
                            }).format(lead.estimated_value)}
                          </TableCell>
                          <TableCell>
                            <div className="max-w-xs truncate text-sm">{lead.notes}</div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="manage">
          <Card>
            <CardHeader>
              <CardTitle>Lead Assignment Management</CardTitle>
              <CardDescription>View and manage lead assignments across your team</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-muted-foreground">
                Lead assignment management interface will be displayed here. This would show all current assignments and
                allow bulk reassignment operations.
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
