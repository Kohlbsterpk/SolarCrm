"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import type { User } from "@supabase/supabase-js"
import { supabase } from "@/lib/supabase"

interface AuthContextType {
  user: User | null
  userProfile: any | null
  loading: boolean
  signOut: () => Promise<void>
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  userProfile: null,
  loading: true,
  signOut: async () => {},
})

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [userProfile, setUserProfile] = useState<any | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null)
      if (session?.user) {
        fetchUserProfile(session.user.id)
      } else {
        setLoading(false)
      }
    })

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      setUser(session?.user ?? null)
      if (session?.user) {
        fetchUserProfile(session.user.id)
      } else {
        setUserProfile(null)
        setLoading(false)
      }
    })

    return () => subscription.unsubscribe()
  }, [])

  const fetchUserProfile = async (userId: string) => {
    try {
      // First try to get the user profile with role information
      const { data, error } = await supabase
        .from("user_profiles")
        .select(`
        id,
        full_name,
        role_id,
        created_at,
        updated_at,
        roles!user_profiles_role_id_fkey (
          id,
          name
        )
      `)
        .eq("id", userId)
        .single()

      if (error) {
        // If user profile doesn't exist, create one with default role
        if (error.code === "PGRST116") {
          const { error: insertError } = await supabase.from("user_profiles").insert({
            id: userId,
            full_name: user?.email || "New User",
            role_id: 2, // Default to sales_rep
          })

          if (insertError) throw insertError

          // Retry fetching the profile
          return fetchUserProfile(userId)
        }
        throw error
      }

      setUserProfile(data)
    } catch (error) {
      console.error("Error fetching user profile:", error)
      // Set a minimal profile to prevent infinite loops
      setUserProfile({
        id: userId,
        full_name: user?.email || "User",
        role_id: 2,
        roles: { name: "sales_rep" },
      })
    } finally {
      setLoading(false)
    }
  }

  const signOut = async () => {
    await supabase.auth.signOut()
  }

  return <AuthContext.Provider value={{ user, userProfile, loading, signOut }}>{children}</AuthContext.Provider>
}
